<?php

namespace Database\Seeders;

use App\Models\PaymentGateway;
use Illuminate\Database\Seeder;

class PaymentGatewaySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        PaymentGateway::truncate();
        $paymentMethods = [
            [
                'title'             => 'Stripe',
                'name'              => 'stripe',
                'config'            => json_encode([
                    'secret_key'    => 'sk_test_51LQPRBI8v6B8L0HsH8JBOEoUuzy0OMkhiOeqfiei1AHEkZBUnmcf7Cv5Go6fwhi3HYayZgjeLxjDsP0DYHcR0xJ1008GRte5Vf',
                    'published_key' => 'pk_test_51LQPRBI8v6B8L0HsDPqZN4PY9gpuOvAktw3bqhvqWfo3zXs7Xe6S1hntVX7hZjVIVCDQ76nroy0nHUYGpRjt0lbT00aiqqq3M7',
                ]),
                'mode'              => 'test',
                'alias'             => 'stripe',
                'is_active'         => true,
            ],
            [
                'title'             => 'Razorpay',
                'name'              => 'razorpay',
                'config'            => json_encode([
                    'key'           => 'rzp_test_k23Mr4BskGqpBu',
                    'secret'        => 'LTrXh7U5xWeZoAHcqdhemFkg',
                ]),
                'mode'              => 'test',
                'alias'             => 'razorpay',
                'is_active'         => true,
            ],
            [
                'title'             => 'Paystack',
                'name'              => 'paystack',
                'config'            => json_encode([
                    'public_key'    => 'pk_test_0c871ddaa80aafd5b64f14390e0745a6c3c274bc',
                    'secret_key'    => 'sk_test_03c7e6762cf1772676272d4677e21e60323610aa',
                    'machant_email' => '',
                ]),
                'mode'              => 'test',
                'alias'             => 'paystack',
                'is_active'         => true,
            ],
        ];

        PaymentGateway::insert($paymentMethods);
    }
}
