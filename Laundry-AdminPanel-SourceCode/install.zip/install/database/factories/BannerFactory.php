<?php

namespace Database\Factories;

use App\Models\Banner;
use App\Models\Media;
use Illuminate\Database\Eloquent\Factories\Factory;

class BannerFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Banner::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'title' => $this->faker->word,
            'description' => $this->faker->sentence(),
            'thumbnail_id' => Media::factory()->create(),
            'is_active' => $this->faker->boolean(),
            'is_banner' => $this->faker->boolean(),
        ];
    }
}
